## imports ##
import os
import sys

sys.path.append(os.getcwd()+'/random_forest')

## import relevant functionality ##
from statmodels.random_forest.RandomForestRegressor import *