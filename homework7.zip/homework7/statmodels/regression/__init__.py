## imports ##
import os
import sys

## set path to package ##
sys.path.append(os.getcwd()+'/regression')

## import relevant functionality ##
from statmodels.regression.regression import *